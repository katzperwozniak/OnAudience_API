# onaudience_api

Repository used to assign different types of datapoints to users in OnAudience DMP.

Available datapoints:
- event(s)
- number attribute(s)
- string attribute(s)

